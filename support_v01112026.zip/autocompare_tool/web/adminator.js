"use strict";

function prepareAdminatorLayout() {
  const navigation = {
    compare: ["git-compare-arrows", "Compare CSV"],
    "excel-compare": ["file-diff", "Compare Excel"],
    "pdf-compare": ["files", "Compare PDF"],
    "image-compare": ["images", "Compare Image"],
    "text-compare": ["columns-3", "File Compare"],
    "search-replace": ["search-code", "Search & Replace"],
    "file-tools": ["folder-cog", "File / Folder"],
    "excel-format": ["file-spreadsheet", "Format Excel"],
    database: ["database", "Database"],
  };
  for (const [key, [icon, label]] of Object.entries(navigation)) {
    const button = document.querySelector(`.nav-item[data-page="${key}"]`);
    button.title = label;
    button.setAttribute("aria-label", label);
    button.querySelector("strong").textContent = label;
    button.querySelector(".nav-icon").innerHTML = `<i data-lucide="${icon}"></i>`;
  }
  document.querySelectorAll(".browse-button").forEach((button) => {
    const label = button.textContent.trim();
    button.title = label;
    button.setAttribute("aria-label", label);
    button.innerHTML = '<i data-lucide="folder-open"></i>';
  });
  document.querySelectorAll('.primary-button > b').forEach((node) => node.remove());
  const backdrop = document.createElement("button");
  backdrop.className = "menu-backdrop";
  backdrop.id = "menu-backdrop";
  backdrop.type = "button";
  backdrop.setAttribute("aria-label", "Đóng menu");
  document.body.append(backdrop);
  prepareCompareWorkbench();
  prepareCompactWorkspaces();
  for (const id of ["compare-preview-card", "fixme-expand-card"]) {
    const panel = document.getElementById(id);
    const actions = panel.querySelector(".card-heading .inline-actions");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "icon-button expand-panel";
    button.title = "Phóng to kết quả";
    button.setAttribute("aria-label", button.title);
    button.setAttribute("aria-pressed", "false");
    button.innerHTML = '<i data-lucide="maximize-2"></i>';
    button.addEventListener("click", () => {
      const expanded = panel.classList.toggle("panel-expanded");
      if (id === "compare-preview-card") placeComparePageToolbar(panel, expanded);
      button.setAttribute("aria-pressed", String(expanded));
      button.title = expanded ? "Thu nhỏ kết quả" : "Phóng to kết quả";
      button.setAttribute("aria-label", button.title);
      button.innerHTML = `<i data-lucide="${expanded ? "minimize-2" : "maximize-2"}"></i>`;
      window.lucide?.createIcons();
    });
    actions.append(button);
  }
  prepareComparePageToolbar();
  prepareWorkspaceDesign();
  prepareFileToolsLayout();
  prepareSyncWorkspace();
  prepareWorkspaceGuides();
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") document.querySelector(".panel-expanded .expand-panel")?.click();
  });
  window.lucide?.createIcons();
}

function prepareFileToolsLayout() {
  const icons = { "rename-exact-form": "text-cursor-input", "rename-contains-form": "replace", "delete-contains-form": "trash-2", "rename-sheets-form": "file-spreadsheet", "move-files-form": "folder-input" };
  document.querySelectorAll("#page-file-tools .tool-card").forEach(card => {
    if (card.querySelector(".tool-heading")) return;
    const icon = card.querySelector(":scope > .tool-icon");
    const title = card.querySelector(":scope > h3");
    const description = card.querySelector(":scope > p");
    const heading = document.createElement("div");
    heading.className = "tool-heading";
    icon.className = "tool-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = `<i data-lucide="${icons[card.id] || "folder-search"}"></i>`;
    const text = document.createElement("div");
    text.append(title, description);
    heading.append(icon, text);
    card.prepend(heading);
    const actions = card.querySelector(":scope > .inline-actions") || document.createElement("div");
    actions.classList.add("tool-actions");
    card.querySelectorAll(":scope > button").forEach(button => {
      button.classList.remove("full");
      actions.append(button);
    });
    card.append(actions);
  });
}

function prepareSyncWorkspace() {
  const form = document.getElementById("db-sync-form");
  if (!form || form.querySelector(".sync-workspace-grid")) return;
  const heading = form.querySelector(":scope > .card-heading");
  heading.querySelector(".step-number").textContent = "1";
  heading.querySelector("h3").textContent = "Chọn table";
  const scopeToggle = form.querySelector(":scope > .switch-row");
  const picker = form.querySelector(".table-picker");
  const method = form.querySelector(":scope > .import-mode-fieldset");
  const condition = document.getElementById("sync-condition-panel");
  const [technical, safety] = form.querySelectorAll(":scope > .two-column");
  const progress = document.getElementById("sync-progress-panel");
  const actions = form.querySelector(":scope > .form-actions");
  const direction = document.createElement("div");
  direction.className = "sync-route";
  direction.innerHTML = '<span><b>Database 1</b> Nguồn</span><span aria-hidden="true">→</span><span><b>Database 2</b> Đích</span><small>Cấu hình và kiểm tra cả hai trong “Kết nối CSDL”.</small>';
  const grid = document.createElement("div");
  grid.className = "sync-workspace-grid";
  const scope = document.createElement("section");
  scope.className = "sync-scope-section";
  scope.append(heading, scopeToggle, picker);
  const settings = document.createElement("section");
  settings.className = "sync-settings-section";
  settings.innerHTML = '<div class="card-heading"><div><span class="step-number">2</span><h3>Cách đồng bộ</h3></div></div>';
  const advanced = document.createElement("details");
  advanced.className = "sync-advanced";
  advanced.innerHTML = '<summary>Tùy chọn kỹ thuật · số record, batch và thời gian chờ</summary>';
  advanced.append(technical);
  safety.classList.add("sync-safety-options");
  settings.append(method, safety, advanced);
  grid.append(scope, settings);
  form.append(direction, grid, condition, progress, actions);
}

function prepareWorkspaceDesign() {
  const groups = [["file-tools", "Công cụ workbook"], ["database", "Cơ sở dữ liệu"]];
  for (const [page, label] of groups) {
    const item = document.querySelector(`.nav-item[data-page="${page}"]`);
    const heading = document.createElement("span");
    heading.className = "nav-label nav-group-label";
    heading.textContent = label;
    item.before(heading);
  }

  const hints = {
    "excel-format-root": "Chọn thư mục chứa workbook cần định dạng…",
  };
  for (const [id, placeholder] of Object.entries(hints)) {
    const input = document.getElementById(id);
    if (input) input.placeholder = placeholder;
  }
}

function prepareComparePageToolbar() {
  const page = document.getElementById("page-compare");
  const intro = page?.querySelector(".page-intro");
  const panel = document.getElementById("compare-preview-card");
  const heading = panel?.querySelector(":scope > .card-heading");
  const bulk = document.getElementById("compare-bulk-tools");
  if (!intro || !panel || !heading || !bulk || document.getElementById("compare-page-toolbar")) return;
  const toolbar = document.createElement("div");
  toolbar.id = "compare-page-toolbar";
  toolbar.className = "compare-page-toolbar hidden";
  toolbar.setAttribute("aria-label", "Thao tác workbook compare");
  toolbar.append(heading, bulk);
  intro.append(toolbar);
}

function placeComparePageToolbar(panel, expanded) {
  const toolbar = document.getElementById("compare-page-toolbar");
  const intro = document.querySelector("#page-compare > .page-intro");
  if (!toolbar || !intro) return;
  if (expanded) {
    panel.prepend(toolbar);
    toolbar.classList.remove("hidden");
  } else {
    intro.append(toolbar);
  }
}

function prepareCompactWorkspaces() {
  const csvForm = document.getElementById("db-csv-form");

  document.querySelectorAll("#page-database .import-mode-card, #page-database .switch-row").forEach((label) => {
    const description = label.querySelector("small");
    if (description) label.title = description.textContent;
  });
  const loader = document.querySelector(".sql-excel-loader");
  const details = document.createElement("details");
  details.className = "sql-excel-details";
  details.innerHTML = '<summary><i data-lucide="file-spreadsheet" aria-hidden="true"></i>SQL từ Excel</summary>';
  loader.before(details);
  details.append(loader);

  const icons = {
    "copy-current-sql": ["copy", "Copy SQL", false],
    "sql-format": ["align-left", "Format SQL", false],
    "sql-analyze": ["scan-search", "Phân tích", false],
    "sql-run-current": ["play", "Chạy hiện tại", false],
    "sql-run-all": ["list-start", "Chạy toàn bộ", false],
    "db-scan-csv": ["list-checks", "Quét file CSV", false],
    "db-copy-all-tables": ["copy", "Copy all table", false],
    "db-import": ["upload", "Import All", false],
    "db-import-selected": ["upload-cloud", "Import Single", false],
    "db-export": ["download", "Export CSV", false],
  };
  for (const [id, [icon, label, iconOnly]] of Object.entries(icons)) {
    const button = document.getElementById(id);
    if (!button) continue;
    button.title = label;
    button.setAttribute("aria-label", label);
    button.classList.add("compact-tool-button");
    if (iconOnly) button.classList.add("icon-button");
    button.innerHTML = `<i data-lucide="${icon}" aria-hidden="true"></i>${iconOnly ? "" : `<span>${label}</span>`}`;
  }
}

const COMPARE_MODE_KEY = "autocompare:compare-mode";

function prepareCompareWorkbench() {
  const page = document.getElementById("page-compare");
  const tabs = document.createElement("div");
  tabs.className = "workbench-tabs cc-modes";
  tabs.setAttribute("role", "tablist");
  tabs.setAttribute("aria-label", "Chế độ so sánh CSV");
  // The mode tabs and, on the results tab, the workbook toolbar share one row.
  page.querySelector(".page-intro").prepend(tabs);
  const sections = [
    ["compare-form", "Theo cấu trúc folder", "Tự động · nhiều case cùng lúc", "folder-tree"],
    ["folder-compare-form", "So sánh 2 thư mục", "Chọn tay hai thư mục CSV bất kỳ", "folders"],
    ["compare-preview-card", "Kết quả", "Workbook và review FIXME", "table-2"],
  ];
  document.getElementById("fixme-expand-card")?.classList.add("hidden");
  const activate = (target) => {
    tabs.querySelectorAll("button").forEach((button) => {
      const active = button === target;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", String(active));
      button.tabIndex = active ? 0 : -1;
      document.getElementById(button.getAttribute("aria-controls")).classList.toggle("active", active);
    });
    if (target.id !== "tab-compare-preview-card") {
      try { window.localStorage.setItem(COMPARE_MODE_KEY, target.id.slice(4)); } catch { /* the remembered mode is a convenience */ }
    }
    const compareToolbar = document.getElementById("compare-page-toolbar");
    const comparePanel = document.getElementById("compare-preview-card");
    compareToolbar?.classList.toggle(
      "hidden",
      target.id !== "tab-compare-preview-card" || comparePanel?.classList.contains("hidden"),
    );
    if (target.id === "tab-compare-preview-card" && !comparePanel?.classList.contains("hidden")) {
      window.requestAnimationFrame(expandComparePanelFromTab);
    }
  };
  sections.forEach(([id, label, description, icon], index) => {
    const content = document.getElementById(id);
    const panel = document.createElement("div");
    panel.id = `workbench-${id}`;
    panel.className = `workbench-panel${index === 0 ? " active" : ""}`;
    panel.setAttribute("role", "tabpanel");
    panel.setAttribute("aria-labelledby", `tab-${id}`);
    const tab = document.createElement("button");
    tab.id = `tab-${id}`;
    tab.className = `workbench-tab${index === 0 ? " active" : ""}`;
    tab.type = "button";
    tab.innerHTML = `<i data-lucide="${icon}" aria-hidden="true"></i><span class="cc-tab-text"><strong>${label}</strong><small>${description}</small></span>${id === "compare-preview-card" ? '<span class="cc-tab-count hidden" id="compare-result-count"></span>' : ""}`;
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-controls", panel.id);
    tab.setAttribute("aria-selected", String(index === 0));
    tab.tabIndex = index === 0 ? 0 : -1;
    tab.addEventListener("click", () => activate(tab));
    tabs.append(tab);
    panel.append(content);
    page.append(panel);
    if (id === "compare-preview-card") {
      const empty = document.createElement("div");
      empty.className = "workbench-empty";
      empty.innerHTML = '<i data-lucide="table-2"></i><strong>Chưa có workbook</strong>';
      panel.append(empty);
      const updateEmpty = () => empty.classList.toggle("hidden", !content.classList.contains("hidden"));
      new MutationObserver(updateEmpty).observe(content, { attributes: true, attributeFilter: ["class"] });
      updateEmpty();
    }
  });
  tabs.addEventListener("keydown", (event) => {
    const buttons = [...tabs.querySelectorAll("button")];
    const index = buttons.indexOf(document.activeElement);
    if (index < 0 || !["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const next = event.key === "Home" ? 0 : event.key === "End" ? buttons.length - 1
      : (index + (event.key === "ArrowRight" ? 1 : -1) + buttons.length) % buttons.length;
    activate(buttons[next]);
    buttons[next].focus();
  });
  // Other code picks a tab by its section id (compare-form, folder-compare-form, compare-preview-card).
  window.selectCompareTab = (id) => document.getElementById(`tab-${id}`)?.click();
  let remembered = "";
  try { remembered = window.localStorage.getItem(COMPARE_MODE_KEY) || ""; } catch { /* ignore */ }
  if (remembered === "folder-compare-form") activate(document.getElementById(`tab-${remembered}`));
}

function expandComparePanelFromTab() {
  const panel = document.getElementById("compare-preview-card");
  if (!panel || panel.classList.contains("hidden") || panel.classList.contains("panel-expanded")) return;
  const button = document.querySelector("#compare-page-toolbar .expand-panel")
    || panel.querySelector(".expand-panel");
  button?.click();
}
